// Stop loading important!
window.onload = function () {
jQuery('.spinnerbg').hide() 
};